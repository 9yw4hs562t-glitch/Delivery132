import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';

export default function AuthInput({ label, ...props }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={styles.input} {...props} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 20 },
  label: { color: '#8B4513', marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: '#D4A418',
    borderRadius: 10,
    padding: 14
  }
});